#ifndef _APP_H_
#define _APP_H_

enum app_status_t {
  APP_OK = 0,
  APP_ERROR = 1,
} ;

#endif //_APP_H_

