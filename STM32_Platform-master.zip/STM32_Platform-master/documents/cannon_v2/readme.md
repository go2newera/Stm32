For specific chip datasheet, please find it at:  

对于具体某个芯片的手册，可以在这里下载：  

http://pan.baidu.com/s/1o76rwbo


