var struct_i_t_m___type =
[
    [ "PORT", "struct_i_t_m___type.html#af4c205be465780a20098387120bdb482", null ],
    [ "RESERVED0", "struct_i_t_m___type.html#a2c5ae30385b5f370d023468ea9914c0e", null ],
    [ "RESERVED1", "struct_i_t_m___type.html#afffce5b93bbfedbaee85357d0b07ebce", null ],
    [ "RESERVED2", "struct_i_t_m___type.html#af56b2f07bc6b42cd3e4d17e1b27cff7b", null ],
    [ "TCR", "struct_i_t_m___type.html#a04b9fbc83759cb818dfa161d39628426", null ],
    [ "TER", "struct_i_t_m___type.html#acd03c6858f7b678dab6a6121462e7807", null ],
    [ "TPR", "struct_i_t_m___type.html#ae907229ba50538bf370fbdfd54c099a2", null ],
    [ "u16", "struct_i_t_m___type.html#a962a970dfd286cad7f8a8577e87d4ad3", null ],
    [ "u32", "struct_i_t_m___type.html#a5834885903a557674f078f3b71fa8bc8", null ],
    [ "u8", "struct_i_t_m___type.html#ae773bf9f9dac64e6c28b14aa39f74275", null ]
];