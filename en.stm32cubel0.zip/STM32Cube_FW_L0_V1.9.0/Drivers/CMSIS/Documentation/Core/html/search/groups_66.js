var searchData=
[
  ['fpu_20functions_20_28only_20cortex_2dm7_29',['FPU Functions (only Cortex-M7)',['../group__fpu__functions__m7.html',1,'']]]
];
